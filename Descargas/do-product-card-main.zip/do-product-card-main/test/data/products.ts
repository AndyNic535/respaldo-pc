export const product1 = {
    id: '1',
    title: 'Coffee Mug - Sin Imagen',
    // img: './coffee-mug.png'
  }

export const product2 = {
    id: '2',
    title: 'Coffee Mug - Con Imagen',
    img: './coffee-mug.png'
}